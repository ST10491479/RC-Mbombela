public class Message {
    private String recipient;
    private String message;
    private String messageID;
    private String messageHash;

    public String getRecipient() {
        return recipient;
    }

    public void setRecipient(String recipient) {
        this.recipient = recipient;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getMessageID() {
        return messageID;
    }

    public void setMessageID(String messageID) {
        this.messageID = messageID;
    }

    public String getMessageHash() {
        return messageHash;
    }

    public boolean checkRecipientCell() {
        // Ensure the recipient starts with +27 and is 12 digits long
        return recipient != null && recipient.startsWith("+27") && recipient.length() == 12;
    }

    public boolean checkMessageID() {
        // Ensure the message ID is 10 characters long
        return messageID != null && messageID.length() == 10;
    }

    public void createMessageHash(int messageNumber) {
        String[] words = message.split(" ");
        String first = words.length > 0 ? words[0].toUpperCase() : "";
        String last = words.length > 1 ? words[words.length - 1].toUpperCase() : first;
        this.messageHash = messageID.substring(0, 2) + ":" + messageNumber + ":" + first + ":" + last;
    }

    public String displayFullDetails() {
        return String.format("Message ID: %s\nRecipient: %s\nMessage: %s\nHash: %s",
                messageID, recipient, message, messageHash);
    }

    public static String generateMessageID() {
        // Generate a random 10-digit message ID
        return String.format("%010d", new java.util.Random().nextInt(1000000000));
    }
}
