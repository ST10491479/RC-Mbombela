package poe;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;


import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class POE extends JFrame {

    private static final String STORAGE_FILE = "messages.json";
    private final JTextArea chatArea = new JTextArea();
    private final JTextField recipientField = new JTextField(15);
    private final JTextArea messageInput = new JTextArea(3, 30);
    private final JButton sendButton = new JButton("Send Message 🚀");
    private final JButton summaryButton = new JButton("Show Summary 📜");

    private List<Message> storedMessages;
    private final String loggedInUser;
    private int currentMessageNumber;

    private static final int MAX_MESSAGE_LENGTH = 50;

    private final Color pinkLight = new Color(255, 228, 241);
    private final Color pinkAccent = new Color(255, 105, 180);

    public POE(String username) {
        this.loggedInUser = username;
        this.storedMessages = loadMessagesFromFile();
        this.currentMessageNumber = storedMessages.size();

        setTitle("QuickChat 💖 | Logged in as " + username);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(650, 450);
        setLocationRelativeTo(null);

        setupUI();

        chatArea.append("Welcome back! Total stored/sent messages: " + storedMessages.size() + "\n\n");

        setVisible(true);
    }

    private void setupUI() {
        chatArea.setEditable(false);
        chatArea.setBackground(Color.WHITE);
        chatArea.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        chatArea.setLineWrap(true);
        chatArea.setWrapStyleWord(true);
        JScrollPane chatScrollPane = new JScrollPane(chatArea);
        chatScrollPane.setBorder(BorderFactory.createLineBorder(pinkAccent, 1));

        recipientField.setBackground(Color.WHITE);
        recipientField.setBorder(BorderFactory.createLineBorder(pinkAccent, 1));
        recipientField.setFont(new Font("Segoe UI", Font.PLAIN, 13));

        JPanel recipientPanel = new JPanel(new BorderLayout(5, 5));
        recipientPanel.setBackground(pinkLight);
        recipientPanel.add(new JLabel("Recipient Phone (+27...):"), BorderLayout.WEST);
        recipientPanel.add(recipientField, BorderLayout.CENTER);

        messageInput.setBorder(BorderFactory.createLineBorder(pinkAccent, 1));
        messageInput.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        messageInput.setLineWrap(true);
        messageInput.setWrapStyleWord(true);
        JScrollPane messageScrollPane = new JScrollPane(messageInput);

        JPanel inputSectionPanel = new JPanel(new BorderLayout(5, 5));
        inputSectionPanel.setBackground(pinkLight);
        inputSectionPanel.add(new JLabel("Message (Max " + MAX_MESSAGE_LENGTH + " chars):"), BorderLayout.NORTH);
        inputSectionPanel.add(messageScrollPane, BorderLayout.CENTER);

        sendButton.setBackground(pinkAccent);
        sendButton.setForeground(Color.WHITE);
        sendButton.setFocusPainted(false);
        sendButton.setFont(new Font("Segoe UI", Font.BOLD, 13));
        sendButton.addActionListener(new MessageActionListener());

        summaryButton.setBackground(pinkAccent.darker());
        summaryButton.setForeground(Color.WHITE);
        summaryButton.setFocusPainted(false);
        summaryButton.setFont(new Font("Segoe UI", Font.BOLD, 13));
        summaryButton.addActionListener(e -> showSummary());

        JPanel actionButtonPanel = new JPanel(new GridLayout(1, 2, 10, 5));
        actionButtonPanel.setBackground(pinkLight);
        actionButtonPanel.add(sendButton);
        actionButtonPanel.add(summaryButton);

        JPanel bottomPanel = new JPanel(new BorderLayout(10, 10));
        bottomPanel.setBackground(pinkLight);
        bottomPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        bottomPanel.add(recipientPanel, BorderLayout.NORTH);
        bottomPanel.add(inputSectionPanel, BorderLayout.CENTER);
        bottomPanel.add(actionButtonPanel, BorderLayout.SOUTH);

        add(chatScrollPane, BorderLayout.CENTER);
        add(bottomPanel, BorderLayout.SOUTH);
    }

    private class MessageActionListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String recipient = recipientField.getText().trim();
            String messageText = messageInput.getText().trim();

            if (recipient.isEmpty() || messageText.isEmpty()) {
                JOptionPane.showMessageDialog(POE.this, "Please fill in recipient and message.", "Input Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (messageText.length() > MAX_MESSAGE_LENGTH) {
                JOptionPane.showMessageDialog(POE.this, "Message exceeds " + MAX_MESSAGE_LENGTH + " characters, please reduce size.", "Message Too Long", JOptionPane.ERROR_MESSAGE);
                return;
            }

            Message msg = new Message();
            msg.setRecipient(recipient);
            msg.setMessage(messageText);

            if (!msg.checkRecipientCell()) {
                JOptionPane.showMessageDialog(POE.this, "Recipient number invalid. Must start with '+' and contain only digits.", "Recipient Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Generate and check Message ID
            msg.setMessageID(generateMessageID());
            if (!msg.checkMessageID()) {
                JOptionPane.showMessageDialog(POE.this, "Generated Message ID invalid (length).", "ID Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            msg.createMessageHash(currentMessageNumber);

            String[] options = {"Send Message", "Store Message", "Disregard"};
            int choice = JOptionPane.showOptionDialog(POE.this, "What would you like to do with this message?\n\n" + msg.displayFullDetails(), "Message Options", JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, null, options, options[0]);

            handleMessageChoice(msg, choice);
        }
    }

    private void handleMessageChoice(Message msg, int choice) {
        String status;
        switch (choice) {
            case 0: // Send Message
            case 1: // Store Message
                storedMessages.add(msg);
                currentMessageNumber++;
                saveMessagesToFile(storedMessages);
                status = (choice == 0 ? "Message successfully SENT" : "Message successfully STORED") + " and logged. Total: " + currentMessageNumber;
                break;
            case 2: // Disregard Message
            default:
                status = "Message DISREGARDED. Not saved.";
                return;
        }

        chatArea.append(">> " + loggedInUser + " to " + msg.getRecipient() + ": " + status + "\n");
        recipientField.setText("");
        messageInput.setText("");

        JOptionPane.showMessageDialog(POE.this, status, "Message Status", JOptionPane.INFORMATION_MESSAGE);
    }

    private void showSummary() {
        if (storedMessages.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No messages have been sent or stored yet.", "Summary", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        StringBuilder sb = new StringBuilder();
        sb.append("--- Message Summary ---\n");
        sb.append("Total messages processed (sent/stored): ").append(currentMessageNumber).append("\n\n");

        int idx = 1;
        for (Message m : storedMessages) {
            JOptionPane.showMessageDialog(this, "Message " + idx + " Details:\n" + m.displayFullDetails(), "Summary: Message " + idx, JOptionPane.INFORMATION_MESSAGE);
            sb.append(String.format("%d. ID: %s, Hash: %s, Recipient: %s\n", idx++, m.getMessageID(), m.getMessageHash(), m.getRecipient()));
        }

        JOptionPane.showMessageDialog(this, sb.toString(), "Final Summary", JOptionPane.INFORMATION_MESSAGE);
    }

    private List<Message> loadMessagesFromFile() {
        File f = new File(STORAGE_FILE);
        if (!f.exists()) {
            return new ArrayList<>();
        }
        try (Reader reader = new FileReader(f)) {
            Gson gson = new GsonBuilder().create();
            Type listType = new TypeToken<List<Message>>() {}.getType();
            List<Message> list = gson.fromJson(reader, listType);
            return (list == null) ? new ArrayList<>() : list;
        } catch (IOException e) {
            System.err.println("Could not load stored messages: " + e.getMessage());
            return new ArrayList<>();
        }
    }

    private void saveMessagesToFile(List<Message> messages) {
        try (Writer writer = new FileWriter(STORAGE_FILE)) {
            Gson gson = new GsonBuilder().setPrettyPrinting().create();
            gson.toJson(messages, writer);
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Could not save messages: " + e.getMessage(), "File Error", JOptionPane.ERROR_MESSAGE);
        }
    }
public void testGsonSerialization() {
    // Create a sample message
    List<Message> messages = new ArrayList<>();
    Message msg = new Message();
    msg.setRecipient("+27718693002");
    msg.setMessage("Test message");
    msg.setMessageID("1234567890");
    msg.createMessageHash(1);
    messages.add(msg);

    // Use Gson to convert the message list to JSON
    Gson gson = new GsonBuilder().setPrettyPrinting().create();
    String json = gson.toJson(messages); // Convert messages to JSON
    System.out.println(json); // Print the JSON output in the console
}

    // Generate a unique 10-digit Message ID
    private String generateMessageID() {
        return String.format("%010d", new java.util.Random().nextInt(1000000000));
    }

    // --- Message Class: Handling Message Details ---
    public static class Message {
        private String recipient;
        private String message;
        private String messageID;
        private String messageHash;

        public String getRecipient() {
            return recipient;
        }

        public void setRecipient(String recipient) {
            this.recipient = recipient;
        }

        public String getMessage() {
            return message;
        }

        public void setMessage(String message) {
            this.message = message;
        }

        public String getMessageID() {
            return messageID;
        }

        public void setMessageID(String messageID) {
            this.messageID = messageID;
        }

        public String getMessageHash() {
            return messageHash;
        }

        public boolean checkRecipientCell() {
            return recipient != null && recipient.startsWith("+27") && recipient.length() == 12;
        }

        public boolean checkMessageID() {
            return messageID != null && messageID.length() == 10;
        }

        public void createMessageHash(int messageNumber) {
            String[] words = message.split(" ");
            String first = words.length > 0 ? words[0].toUpperCase() : "";
            String last = words.length > 1 ? words[words.length - 1].toUpperCase() : first;
            this.messageHash = messageID.substring(0, 2) + ":" + messageNumber + ":" + first + ":" + last;
        }

        public String displayFullDetails() {
            return String.format("Message ID: %s\nRecipient: %s\nMessage: %s\nHash: %s",
                    messageID, recipient, message, messageHash);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new POE("SampleUser"));
    }
}
