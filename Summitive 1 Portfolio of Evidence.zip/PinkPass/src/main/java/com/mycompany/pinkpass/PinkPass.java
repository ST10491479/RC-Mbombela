package com.mycompany.pinkpass;

import javax.swing.*;
import java.awt.*;
import java.util.*;
import java.util.List;
import javax.swing.Timer; // explicitly import Swing Timer

// ------------------ MESSAGE CLASS ------------------
class Message {
    private String messageID;
    private String recipient;
    private String message;
    private String messageHash;
    private int numMessage;

    public Message(String recipient, String message, int numMessage) {
        this.recipient = recipient;
        this.message = message;
        this.numMessage = numMessage;
        generateMessageID();
        generateMessageHash();
    }

    private void generateMessageID() {
        this.messageID = String.format("%010d", new Random().nextInt(1_000_000_000));
    }

    private void generateMessageHash() {
        String[] words = message.split(" ");
        String first = words.length > 0 ? words[0].toUpperCase() : "";
        String last = words.length > 1 ? words[words.length - 1].toUpperCase() : first;
        this.messageHash = messageID.substring(0, 2) + ":" + numMessage + ":" + first + ":" + last;
    }

    public String getMessageID() { return messageID; }
    public String getMessageHash() { return messageHash; }
    public String getRecipient() { return recipient; }
    public String getMessage() { return message; }

    public String getSender() {
        return "You"; // Placeholder for sender
    }

    public void showFullDetailsWithTicks(String ticks) {
        JOptionPane.showMessageDialog(null,
                "MessageID: " + messageID + "\n" +
                        "Message Hash: " + messageHash + "\n" +
                        "Recipient: " + recipient + "\n" +
                        "Message: " + message + "\n" +
                        "Status: " + ticks,
                "Message Details",
                JOptionPane.INFORMATION_MESSAGE);
    }

    public String displaySummary() {
        return String.format("MessageID: %s | Recipient: %s | Message: %s | Hash: %s",
                messageID, recipient, message, messageHash);
    }
}

// ------------------ MAIN PINKPASS CLASS ------------------
public class PinkPass extends JFrame {

    private static final Map<String, String[]> users = new HashMap<>();
    private static final Color pinkLight = new Color(255, 228, 241);
    private static final Color pinkAccent = new Color(255, 105, 180);

    public static void main(String[] args) {
        SwingUtilities.invokeLater(PinkPass::new);
    }

    public PinkPass() {
        setTitle("PinkPass – Secure Login System 💖");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH);

        CardLayout cl = new CardLayout();
        JPanel mainPanel = new JPanel(cl);
        mainPanel.setBackground(new Color(255, 182, 193));

        // ------------------ LOGIN PANEL ------------------
        JPanel loginPanel = new JPanel(new GridBagLayout());
        loginPanel.setBackground(pinkLight);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel loginTitle = new JLabel("Welcome to PinkPass 💖");
        loginTitle.setFont(new Font("SansSerif", Font.BOLD, 26));
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        loginPanel.add(loginTitle, gbc);

        JTextField loginUser = new JTextField(18);
        JPasswordField loginPass = new JPasswordField(18);

        gbc.gridwidth = 1;
        gbc.gridx = 0; gbc.gridy = 1;
        loginPanel.add(new JLabel("Username:"), gbc);
        gbc.gridx = 1;
        loginPanel.add(loginUser, gbc);

        gbc.gridx = 0; gbc.gridy = 2;
        loginPanel.add(new JLabel("Password:"), gbc);
        gbc.gridx = 1;
        loginPanel.add(loginPass, gbc);

        JButton loginButton = createButton("Login");
        gbc.gridx = 0; gbc.gridy = 3; gbc.gridwidth = 2;
        loginPanel.add(loginButton, gbc);

        JButton goRegister = createFlatButton("Create an account");
        gbc.gridy = 4;
        loginPanel.add(goRegister, gbc);

        // ------------------ REGISTER PANEL ------------------
        JPanel registerPanel = new JPanel(new GridBagLayout());
        registerPanel.setBackground(pinkLight);
        GridBagConstraints gbc2 = new GridBagConstraints();
        gbc2.insets = new Insets(10, 10, 10, 10);
        gbc2.fill = GridBagConstraints.HORIZONTAL;

        JLabel regTitle = new JLabel("Register 🌸");
        regTitle.setFont(new Font("SansSerif", Font.BOLD, 26));
        gbc2.gridx = 0; gbc2.gridy = 0; gbc2.gridwidth = 2;
        registerPanel.add(regTitle, gbc2);

        JTextField regUser = new JTextField(18);
        JPasswordField regPass = new JPasswordField(18);
        JPasswordField regConfirm = new JPasswordField(18);
        JTextField regContact = new JTextField(18);

        gbc2.gridwidth = 1;
        gbc2.gridx = 0; gbc2.gridy = 1;
        registerPanel.add(new JLabel("Username:"), gbc2);
        gbc2.gridx = 1;
        registerPanel.add(regUser, gbc2);

        gbc2.gridx = 0; gbc2.gridy = 2;
        registerPanel.add(new JLabel("Password:"), gbc2);
        gbc2.gridx = 1;
        registerPanel.add(regPass, gbc2);

        gbc2.gridx = 0; gbc2.gridy = 3;
        registerPanel.add(new JLabel("Confirm Password:"), gbc2);
        gbc2.gridx = 1;
        registerPanel.add(regConfirm, gbc2);

        gbc2.gridx = 0; gbc2.gridy = 4;
        registerPanel.add(new JLabel("Contact (+27):"), gbc2);
        gbc2.gridx = 1;
        registerPanel.add(regContact, gbc2);

        JButton registerButton = createButton("Register");
        gbc2.gridx = 0; gbc2.gridy = 5; gbc2.gridwidth = 2;
        registerPanel.add(registerButton, gbc2);

        JButton goLogin = createFlatButton("Already have an account? Log in");
        gbc2.gridy = 6;
        registerPanel.add(goLogin, gbc2);

        // ------------------ ADD TO MAIN ------------------
        mainPanel.add(loginPanel, "Login");
        mainPanel.add(registerPanel, "Register");
        add(mainPanel);

        // ------------------ ACTIONS ------------------
        goRegister.addActionListener(e -> cl.show(mainPanel, "Register"));
        goLogin.addActionListener(e -> cl.show(mainPanel, "Login"));

        loginButton.addActionListener(e -> {
            String username = loginUser.getText().trim();
            String password = new String(loginPass.getPassword());
            if (users.containsKey(username) && users.get(username)[0].equals(password)) {
                dispose();
                new NumericQuickChat(username);
            } else {
                JOptionPane.showMessageDialog(this, "❌ Invalid login!", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        registerButton.addActionListener(e -> {
            String username = regUser.getText().trim();
            String password = new String(regPass.getPassword());
            String confirm = new String(regConfirm.getPassword());
            String contact = regContact.getText().trim();

            if (username.isEmpty() || password.isEmpty() || confirm.isEmpty() || contact.isEmpty()) {
                JOptionPane.showMessageDialog(this, "⚠ Fill in all fields!", "Error", JOptionPane.WARNING_MESSAGE);
                return;
            }
            if (!password.equals(confirm)) {
                JOptionPane.showMessageDialog(this, "⚠ Passwords do not match!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            if (!contact.matches("0\\d{9}")) {
                JOptionPane.showMessageDialog(this, "⚠ Contact must be 10 digits starting with 0", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            if (users.containsKey(username)) {
                JOptionPane.showMessageDialog(this, "⚠ Username exists!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            users.put(username, new String[]{password, "+27" + contact.substring(1)});
            JOptionPane.showMessageDialog(this, "🎉 Registration Successful, " + username + "!", "Success", JOptionPane.INFORMATION_MESSAGE);
            dispose();
            new NumericQuickChat(username);
        });

        setVisible(true);
    }

    private JButton createButton(String text) {
        JButton btn = new JButton(text);
        btn.setBackground(pinkAccent);
        btn.setForeground(Color.WHITE);
        btn.setFont(new Font("Arial", Font.PLAIN, 16));
        return btn;
    }

    private JButton createFlatButton(String text) {
        JButton btn = new JButton(text);
        btn.setBackground(pinkLight);
        btn.setBorderPainted(false);
        btn.setFont(new Font("Arial", Font.PLAIN, 14));
        return btn;
    }

    // ------------------ NUMERIC MENU QUICKCHAT ------------------
    class NumericQuickChat {
        private java.util.List<Message> sentMessages = new java.util.ArrayList<>();
        private java.util.List<Message> disregardedMessages = new java.util.ArrayList<>();
        private java.util.List<Message> storedMessages = new java.util.ArrayList<>();
        private java.util.List<String> messageIDs = new java.util.ArrayList<>();
        private java.util.List<String> messageHashes = new java.util.ArrayList<>();
        private int messageCounter = 0;

        public NumericQuickChat(String username) {
            JOptionPane.showMessageDialog(null, "Welcome to QuickChat.", "QuickChat", JOptionPane.INFORMATION_MESSAGE);

            boolean running = true;
            while (running) {
                String choice = JOptionPane.showInputDialog(null,
                        "1) Send Messages\n" +
                        "2) Show recently sent messages\n" +
                        "3) Search by Message ID\n" +
                        "4) Search by Recipient\n" +
                        "5) Delete by Message Hash\n" +
                        "6) Show Full Report\n" +
                        "7) Quit",
                        "Menu", JOptionPane.QUESTION_MESSAGE);

                if (choice == null) continue;
                switch (choice) {
                    case "1": sendMessages(username); break;
                    case "2": JOptionPane.showMessageDialog(null, "Coming Soon.", "Info", JOptionPane.INFORMATION_MESSAGE); break;
                    case "3": searchByID(); break;
                    case "4": searchByRecipient(); break;
                    case "5": deleteByHash(); break;
                    case "6": showFullReport(); break;
                    case "7": running = false; break;
                    default: JOptionPane.showMessageDialog(null, "Invalid option.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        }

        private void sendMessages(String username) {
            String countStr = JOptionPane.showInputDialog("How many messages would you like to send?");
            if (countStr == null) return;
            int num;
            try { num = Integer.parseInt(countStr); } 
            catch (NumberFormatException e) { JOptionPane.showMessageDialog(null,"Invalid number.","Error",JOptionPane.ERROR_MESSAGE); return; }

            for (int i = 0; i < num; i++) {
                messageCounter++;
                String recipient = JOptionPane.showInputDialog("Enter recipient (+27xxxxxxxxx):");
                if (recipient == null) break;
                if (!recipient.matches("\\+27\\d{9}")) { JOptionPane.showMessageDialog(null,"Invalid recipient number.","Error",JOptionPane.ERROR_MESSAGE); i--; continue; }

                String msg = JOptionPane.showInputDialog("Enter message (max 250 chars):");
                if (msg == null) break;
                if (msg.length() > 250) { JOptionPane.showMessageDialog(null,"Please enter a message of less than 250 characters.","Error",JOptionPane.ERROR_MESSAGE); i--; continue; }

                String[] options = {"Send Message", "Disregard Message", "Store Message"};
                int opt = JOptionPane.showOptionDialog(null,"Choose an option","Message Option",
                        JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE,null,options,options[0]);

                Message m = new Message(recipient,msg,messageCounter);

                switch (opt) {
                    case 0: // Send message
                        sentMessages.add(m);
                        messageIDs.add(m.getMessageID());
                        messageHashes.add(m.getMessageHash());
                        m.showFullDetailsWithTicks("✔");
                        Timer timer = new Timer(1000, e -> m.showFullDetailsWithTicks("✔✔"));
                        timer.setRepeats(false);
                        timer.start();
                        break;
                    case 1: disregardedMessages.add(m); break;
                    case 2: storedMessages.add(m); break;
                    default: disregardedMessages.add(m);
                }
            }
            JOptionPane.showMessageDialog(null,"Total messages processed: "+messageCounter,"Summary",JOptionPane.INFORMATION_MESSAGE);
        }

        private void searchByID() {
            String id = JOptionPane.showInputDialog("Enter Message ID to search:");
            if (id == null) return;
            for (Message m : sentMessages) {
                if (m.getMessageID().equals(id)) {
                    m.showFullDetailsWithTicks("✔✔");
                    return;
                }
            }
            JOptionPane.showMessageDialog(null,"Message ID not found.","Search Result",JOptionPane.INFORMATION_MESSAGE);
        }

        private void searchByRecipient() {
            String rec = JOptionPane.showInputDialog("Enter recipient (+27xxxxxxxxx) to search:");
            if (rec == null) return;
            StringBuilder sb = new StringBuilder();
            for (Message m : sentMessages) {
                if (m.getRecipient().equals(rec)) sb.append(m.displaySummary()).append("\n");
            }
            JOptionPane.showMessageDialog(null, sb.length()>0 ? sb.toString() : "No messages found.", "Search Result", JOptionPane.INFORMATION_MESSAGE);
        }

        private void deleteByHash() {
            String hash = JOptionPane.showInputDialog("Enter Message Hash to delete:");
            if (hash == null) return;
            Iterator<Message> it = sentMessages.iterator();
            while (it.hasNext()) {
                Message m = it.next();
                if (m.getMessageHash().equals(hash)) {
                    it.remove();
                    messageIDs.remove(m.getMessageID());
                    messageHashes.remove(m.getMessageHash());
                    JOptionPane.showMessageDialog(null,"Message deleted.","Delete",JOptionPane.INFORMATION_MESSAGE);
                    return;
                }
            }
            JOptionPane.showMessageDialog(null,"Message Hash not found.","Delete",JOptionPane.INFORMATION_MESSAGE);
        }

        private void showFullReport() {
            StringBuilder sb = new StringBuilder();
            for (Message m : sentMessages) sb.append(m.displaySummary()).append("\n");
            JOptionPane.showMessageDialog(null, sb.length()>0 ? sb.toString() : "No messages sent yet.", "Full Report", JOptionPane.INFORMATION_MESSAGE);
        }
    }
}