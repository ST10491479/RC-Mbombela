class Messager {
    public enum Status {SENT, DELIVERED, READ}
    private String sender, recipient, message, messageID, messageHash;
    private Status status;

    public Messager(){ this.status=Status.SENT; }
    public String getSender(){return sender;} public void setSender(String s){sender=s;}
    public String getRecipient(){return recipient;} public void setRecipient(String r){recipient=r;}
    public String getMessage(){return message;} public void setMessage(String m){message=m;}
    public String getMessageID(){return messageID;} public void setMessageID(String id){messageID=id;}
    public String getMessageHash(){return messageHash;}
    public Status getStatus(){return status;} public void setStatus(Status s){status=s;}
    public String getTickSymbol(){switch(status){case SENT:return "✓"; case DELIVERED:return "✓✓"; case READ:return "✓✓ (blue)"; default:return "";}}
    public void createMessageHash(int messageNumber){
        String[] words = message.split(" ");
        String first = words.length>0?words[0].toUpperCase():"";
        String last = words.length>1?words[words.length-1].toUpperCase():first;
        this.messageID=String.format("%010d",messageNumber);
        this.messageHash=messageID+":"+first+":"+last;
    }
}